<template>
  <VBase />
</template>
